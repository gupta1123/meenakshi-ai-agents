globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/112ea5a16d2d514f.js",
      "static/chunks/a6eb3679c8f5e308.js",
      "static/chunks/turbopack-34d99975693eca22.js"
    ],
    "/_error": [
      "static/chunks/7e28a2ae2f8af6f7.js",
      "static/chunks/a6eb3679c8f5e308.js",
      "static/chunks/turbopack-30419eaed9e7efc4.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c85a7d07e7b82c9a.js",
    "static/chunks/e48fa16fdc448c1e.js",
    "static/chunks/bae01d964e8808cf.js",
    "static/chunks/d4d3b5445f8b428b.js",
    "static/chunks/turbopack-239ca80af1ac8921.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];